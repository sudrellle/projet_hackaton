"use client"

import { CheckoutForm } from "@/components/checkout/checkout-form"

export default function CommanderPage() {
  return <CheckoutForm />
}
