"use client"

import { Button } from "@/components/ui/button"
import { ChefHat, ArrowDown } from "lucide-react"

export function HeroSection() {
  return (
    <section className="relative overflow-hidden py-24 md:py-32 px-4">
      <div className="absolute inset-0">
        <img
          src="/images/hero-pastries.jpg"
          alt=""
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-background/80 backdrop-blur-sm" />
      </div>
      <div className="relative mx-auto max-w-4xl text-center">
        <div className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-4 py-1.5 text-sm text-muted-foreground mb-8">
          <ChefHat className="h-4 w-4 text-primary" />
          <span>Artisan Patissier depuis 2020</span>
        </div>
        <h1 className="font-serif text-4xl md:text-6xl lg:text-7xl font-bold text-foreground mb-6 text-balance leading-tight">
          L{"'"}Art de la Patisserie Fine
        </h1>
        <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-10 text-pretty leading-relaxed">
          Des creations artisanales preparees chaque jour avec passion. 
          Gateaux, viennoiseries et tartes pour vos moments les plus precieux.
        </p>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <Button
            size="lg"
            className="text-base px-8 py-6 rounded-full"
            onClick={() => document.getElementById("produits")?.scrollIntoView({ behavior: "smooth" })}
          >
            Decouvrir nos produits
          </Button>
          <Button
            variant="outline"
            size="lg"
            className="text-base px-8 py-6 rounded-full bg-transparent"
            onClick={() => document.getElementById("produits")?.scrollIntoView({ behavior: "smooth" })}
          >
            <ArrowDown className="mr-2 h-4 w-4" />
            Voir la carte
          </Button>
        </div>
      </div>
    </section>
  )
}
