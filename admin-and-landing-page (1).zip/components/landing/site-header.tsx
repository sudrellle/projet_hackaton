"use client"

import { Button } from "@/components/ui/button"
import { ShoppingBag, ChefHat } from "lucide-react"
import { useCart } from "@/lib/cart-context"
import { useState } from "react"
import { CartSheet } from "./cart-sheet"
import Link from "next/link"

export function SiteHeader() {
  const { totalItems } = useCart()
  const [cartOpen, setCartOpen] = useState(false)

  return (
    <>
      <header className="sticky top-0 z-50 w-full border-b border-border bg-card/80 backdrop-blur-md">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4">
          <Link href="/" className="flex items-center gap-2">
            <ChefHat className="h-7 w-7 text-primary" />
            <span className="font-serif text-xl font-bold text-foreground">
              Patisserie Delice
            </span>
          </Link>
          <nav className="hidden md:flex items-center gap-8">
            <a
              href="#produits"
              className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
            >
              Nos Produits
            </a>
            <a
              href="#contact"
              className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
            >
              Contact
            </a>
          </nav>
          <Button
            variant="outline"
            size="sm"
            className="relative bg-transparent"
            onClick={() => setCartOpen(true)}
          >
            <ShoppingBag className="h-4 w-4 mr-2" />
            Panier
            {totalItems > 0 && (
              <span className="absolute -top-2 -right-2 flex h-5 w-5 items-center justify-center rounded-full bg-primary text-xs text-primary-foreground font-bold">
                {totalItems}
              </span>
            )}
          </Button>
        </div>
      </header>
      <CartSheet open={cartOpen} onOpenChange={setCartOpen} />
    </>
  )
}
