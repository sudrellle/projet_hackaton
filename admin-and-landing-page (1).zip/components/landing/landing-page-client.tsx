"use client"

import { CartProvider } from "@/lib/cart-context"
import { HeroSection } from "./hero-section"
import { CategoryFilter } from "./category-filter"
import { ProductGrid } from "./product-grid"
import { SiteHeader } from "./site-header"
import { SiteFooter } from "./site-footer"
import type { Product, Category } from "@/lib/types"
import { useState } from "react"

interface LandingPageClientProps {
  categories: Category[]
  products: Product[]
}

export function LandingPageClient({ categories, products }: LandingPageClientProps) {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)

  const filteredProducts = selectedCategory
    ? products.filter((p) => p.category_id === selectedCategory)
    : products

  return (
    <CartProvider>
      <div className="min-h-screen flex flex-col bg-background">
        <SiteHeader />
        <main className="flex-1">
          <HeroSection />
          <section id="produits" className="py-16 px-4">
            <div className="mx-auto max-w-7xl">
              <div className="text-center mb-12">
                <h2 className="font-serif text-3xl md:text-4xl font-bold text-foreground mb-3 text-balance">
                  Nos Creations
                </h2>
                <p className="text-muted-foreground max-w-xl mx-auto text-pretty">
                  Chaque piece est preparee avec soin par nos artisans patissiers, 
                  utilisant les meilleurs ingredients.
                </p>
              </div>
              <CategoryFilter
                categories={categories}
                selectedCategory={selectedCategory}
                onSelect={setSelectedCategory}
              />
              <ProductGrid products={filteredProducts} />
            </div>
          </section>
        </main>
        <SiteFooter />
      </div>
    </CartProvider>
  )
}
