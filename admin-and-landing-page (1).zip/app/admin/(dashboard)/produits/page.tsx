import { createClient } from "@/lib/supabase/server"
import { ProductsManager } from "@/components/admin/products-manager"
import type { Product, Category } from "@/lib/types"

export default async function AdminProductsPage() {
  const supabase = await createClient()

  const { data: products } = await supabase
    .from("products")
    .select("*, categories(*)")
    .eq("deleted", false)
    .order("created_at", { ascending: false })

  const { data: categories } = await supabase
    .from("categories")
    .select("*")
    .order("name")

  return (
    <ProductsManager
      initialProducts={(products as Product[]) || []}
      categories={(categories as Category[]) || []}
    />
  )
}
