import { createClient } from "@/lib/supabase/server"
import { LandingPageClient } from "@/components/landing/landing-page-client"
import type { Product, Category } from "@/lib/types"

export default async function HomePage() {
  const supabase = await createClient()

  const { data: categories } = await supabase
    .from("categories")
    .select("*")
    .order("name")

  const { data: products } = await supabase
    .from("products")
    .select("*, categories(*)")
    .eq("available", true)
    .eq("deleted", false)
    .order("created_at", { ascending: false })

  return (
    <LandingPageClient
      categories={(categories as Category[]) || []}
      products={(products as Product[]) || []}
    />
  )
}
