import { ChefHat, MapPin, Phone, Mail } from "lucide-react"
import { Separator } from "@/components/ui/separator"
import Link from "next/link"

export function SiteFooter() {
  return (
    <footer id="contact" className="bg-foreground text-background py-12 px-4">
      <div className="mx-auto max-w-7xl">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <ChefHat className="h-6 w-6" />
              <span className="font-serif text-xl font-bold">Patisserie Delice</span>
            </div>
            <p className="text-sm opacity-70 leading-relaxed">
              Depuis 2020, nous creons des patisseries artisanales avec les meilleurs
              ingredients pour rendre vos moments inoubliables.
            </p>
          </div>
          <div>
            <h3 className="font-serif font-semibold text-lg mb-4">Contact</h3>
            <ul className="space-y-3 text-sm opacity-70">
              <li className="flex items-center gap-2">
                <MapPin className="h-4 w-4 flex-shrink-0" />
                Douala, Cameroun
              </li>
              <li className="flex items-center gap-2">
                <Phone className="h-4 w-4 flex-shrink-0" />
                +237 6XX XXX XXX
              </li>
              <li className="flex items-center gap-2">
                <Mail className="h-4 w-4 flex-shrink-0" />
                contact@patisserie-delice.com
              </li>
            </ul>
          </div>
          <div>
            <h3 className="font-serif font-semibold text-lg mb-4">Horaires</h3>
            <ul className="space-y-2 text-sm opacity-70">
              <li>Lundi - Vendredi: 7h - 20h</li>
              <li>Samedi: 8h - 21h</li>
              <li>Dimanche: 8h - 14h</li>
            </ul>
          </div>
        </div>
        <Separator className="my-8 bg-background/10" />
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-sm opacity-50">
          <p>2025 Patisserie Delice. Tous droits reserves.</p>
          <Link href="/admin/login" className="hover:opacity-80 transition-opacity">
            Administration
          </Link>
        </div>
      </div>
    </footer>
  )
}
