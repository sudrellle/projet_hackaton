import React from "react"
import type { Metadata } from 'next'
import { Playfair_Display, Lato } from 'next/font/google'
import { Toaster } from '@/components/ui/sonner'

import './globals.css'

const playfair = Playfair_Display({ subsets: ['latin'], variable: '--font-serif' })
const lato = Lato({ subsets: ['latin'], weight: ['300', '400', '700', '900'], variable: '--font-sans' })

export const metadata: Metadata = {
  title: 'Patisserie Delice - Artisan Pastries',
  description: 'Decouvrez nos creations artisanales de patisserie fine. Commandez en ligne vos gateaux, viennoiseries et tartes.',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="fr">
      <body className={`${playfair.variable} ${lato.variable} font-sans antialiased`}>
        {children}
        <Toaster richColors position="top-right" />
      </body>
    </html>
  )
}
