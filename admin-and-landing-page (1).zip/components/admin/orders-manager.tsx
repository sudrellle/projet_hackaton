"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { Search, Eye, Loader2, Phone, Mail, MapPin, Clock, CalendarDays, MessageSquare, Truck, Store } from "lucide-react"
import {
  formatPrice,
  ORDER_STATUS_LABELS,
  ORDER_STATUS_COLORS,
  type Order,
  type OrderStatus,
} from "@/lib/types"
import { toast } from "sonner"

interface OrdersManagerProps {
  initialOrders: Order[]
}

const STATUS_OPTIONS: OrderStatus[] = [
  "pending_payment",
  "paid",
  "partially_paid",
  "confirmed",
  "preparing",
  "ready",
  "delivered",
  "cancelled",
]

export function OrdersManager({ initialOrders }: OrdersManagerProps) {
  const [orders, setOrders] = useState(initialOrders)
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null)
  const [detailOpen, setDetailOpen] = useState(false)
  const [isUpdating, setIsUpdating] = useState(false)
  const [paymentAmount, setPaymentAmount] = useState("")
  const router = useRouter()

  const filteredOrders = orders.filter((o) => {
    const matchesSearch =
      o.order_number.toLowerCase().includes(searchQuery.toLowerCase()) ||
      o.client_first_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      o.client_last_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      o.client_phone.includes(searchQuery)
    const matchesStatus = statusFilter === "all" || o.status === statusFilter
    return matchesSearch && matchesStatus
  })

  function openDetail(order: Order) {
    setSelectedOrder(order)
    setPaymentAmount("")
    setDetailOpen(true)
  }

  async function updateStatus(orderId: string, newStatus: OrderStatus) {
    setIsUpdating(true)
    const supabase = createClient()
    try {
      const { error } = await supabase
        .from("orders")
        .update({ status: newStatus, updated_at: new Date().toISOString() })
        .eq("id", orderId)
      if (error) throw error

      setOrders((prev) =>
        prev.map((o) => (o.id === orderId ? { ...o, status: newStatus } : o))
      )
      if (selectedOrder?.id === orderId) {
        setSelectedOrder((prev) => prev ? { ...prev, status: newStatus } : null)
      }
      toast.success("Statut mis a jour")
      router.refresh()
    } catch {
      toast.error("Erreur lors de la mise a jour")
    } finally {
      setIsUpdating(false)
    }
  }

  async function recordPayment(orderId: string) {
    const amount = Math.round(Number(paymentAmount))
    if (!amount || amount <= 0) {
      toast.error("Montant invalide")
      return
    }

    setIsUpdating(true)
    const supabase = createClient()
    try {
      const order = orders.find((o) => o.id === orderId)
      if (!order) return

      const newAmountPaid = order.amount_paid + amount
      const newRemaining = order.total - newAmountPaid
      const newStatus: OrderStatus = newRemaining <= 0 ? "paid" : "partially_paid"

      const { error } = await supabase
        .from("orders")
        .update({
          amount_paid: newAmountPaid,
          remaining_balance: Math.max(0, newRemaining),
          status: newStatus,
          updated_at: new Date().toISOString(),
        })
        .eq("id", orderId)
      if (error) throw error

      const updatedOrder = {
        ...order,
        amount_paid: newAmountPaid,
        remaining_balance: Math.max(0, newRemaining),
        status: newStatus,
      }

      setOrders((prev) => prev.map((o) => (o.id === orderId ? updatedOrder : o)))
      setSelectedOrder(updatedOrder)
      setPaymentAmount("")
      toast.success(`Paiement de ${formatPrice(amount)} enregistre`)
      router.refresh()
    } catch {
      toast.error("Erreur lors de l'enregistrement du paiement")
    } finally {
      setIsUpdating(false)
    }
  }

  return (
    <div>
      <div className="mb-6">
        <h1 className="font-serif text-3xl font-bold text-foreground">Commandes</h1>
        <p className="text-muted-foreground mt-1">
          Gerez les commandes de vos clients ({orders.length})
        </p>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Rechercher par nom, numero, telephone..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="Filtrer par statut" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous les statuts</SelectItem>
                {STATUS_OPTIONS.map((s) => (
                  <SelectItem key={s} value={s}>
                    {ORDER_STATUS_LABELS[s]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>N. Commande</TableHead>
                <TableHead>Client</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Mode</TableHead>
                <TableHead className="text-right">Total</TableHead>
                <TableHead className="text-center">Statut</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredOrders.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                    Aucune commande trouvee.
                  </TableCell>
                </TableRow>
              ) : (
                filteredOrders.map((order) => (
                  <TableRow key={order.id}>
                    <TableCell className="font-mono text-sm text-foreground">{order.order_number}</TableCell>
                    <TableCell>
                      <div>
                        <p className="font-medium text-sm text-foreground">
                          {order.client_first_name} {order.client_last_name}
                        </p>
                        <p className="text-xs text-muted-foreground">{order.client_phone}</p>
                      </div>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {new Date(order.created_at).toLocaleDateString("fr-FR")}
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary" className="text-xs">
                        {order.delivery_mode === "delivery" ? "Livraison" : "Retrait"}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right font-mono text-foreground">
                      {formatPrice(order.total)}
                    </TableCell>
                    <TableCell className="text-center">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${ORDER_STATUS_COLORS[order.status]}`}>
                        {ORDER_STATUS_LABELS[order.status]}
                      </span>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openDetail(order)}>
                        <Eye className="h-3.5 w-3.5" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Order Detail Dialog */}
      <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto bg-card text-card-foreground">
          {selectedOrder && (
            <>
              <DialogHeader>
                <DialogTitle className="font-serif text-foreground">
                  Commande {selectedOrder.order_number}
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-6 py-2">
                {/* Status */}
                <div className="flex items-center justify-between">
                  <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${ORDER_STATUS_COLORS[selectedOrder.status]}`}>
                    {ORDER_STATUS_LABELS[selectedOrder.status]}
                  </span>
                  <Select
                    value={selectedOrder.status}
                    onValueChange={(val) => updateStatus(selectedOrder.id, val as OrderStatus)}
                    disabled={isUpdating}
                  >
                    <SelectTrigger className="w-[200px]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {STATUS_OPTIONS.map((s) => (
                        <SelectItem key={s} value={s}>
                          {ORDER_STATUS_LABELS[s]}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <Separator />

                {/* Client Info */}
                <div>
                  <h3 className="font-semibold text-sm text-foreground mb-3">Informations client</h3>
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <span className="font-medium text-foreground">
                        {selectedOrder.client_first_name} {selectedOrder.client_last_name}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Phone className="h-3.5 w-3.5" />
                      {selectedOrder.client_phone}
                    </div>
                    {selectedOrder.client_email && (
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <Mail className="h-3.5 w-3.5" />
                        {selectedOrder.client_email}
                      </div>
                    )}
                  </div>
                </div>

                <Separator />

                {/* Delivery Info */}
                <div>
                  <h3 className="font-semibold text-sm text-foreground mb-3">Reception</h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      {selectedOrder.delivery_mode === "delivery" ? (
                        <Truck className="h-3.5 w-3.5" />
                      ) : (
                        <Store className="h-3.5 w-3.5" />
                      )}
                      {selectedOrder.delivery_mode === "delivery" ? "Livraison" : "Retrait en boutique"}
                    </div>
                    {selectedOrder.delivery_address && (
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <MapPin className="h-3.5 w-3.5" />
                        {selectedOrder.delivery_address}
                        {selectedOrder.address_complement && ` - ${selectedOrder.address_complement}`}
                      </div>
                    )}
                    {selectedOrder.pickup_point && (
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <MapPin className="h-3.5 w-3.5" />
                        {selectedOrder.pickup_point}
                      </div>
                    )}
                    <div className="flex items-center gap-4">
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <CalendarDays className="h-3.5 w-3.5" />
                        {new Date(selectedOrder.delivery_date).toLocaleDateString("fr-FR")}
                      </div>
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <Clock className="h-3.5 w-3.5" />
                        {selectedOrder.delivery_time}
                      </div>
                    </div>
                    {selectedOrder.special_instructions && (
                      <div className="flex items-start gap-2 text-muted-foreground">
                        <MessageSquare className="h-3.5 w-3.5 mt-0.5" />
                        {selectedOrder.special_instructions}
                      </div>
                    )}
                  </div>
                </div>

                <Separator />

                {/* Order Items */}
                <div>
                  <h3 className="font-semibold text-sm text-foreground mb-3">Articles</h3>
                  <div className="space-y-2">
                    {selectedOrder.order_items?.map((item) => (
                      <div key={item.id} className="flex justify-between items-center p-2 rounded bg-muted/50 text-sm">
                        <div>
                          <span className="font-medium text-foreground">{item.product_name}</span>
                          <span className="text-muted-foreground"> x{item.quantity}</span>
                        </div>
                        <span className="font-mono text-foreground">{formatPrice(item.unit_price * item.quantity)}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <Separator />

                {/* Totals */}
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Sous-total</span>
                    <span className="text-foreground">{formatPrice(selectedOrder.subtotal)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Frais de livraison</span>
                    <span className="text-foreground">
                      {selectedOrder.delivery_fee > 0 ? formatPrice(selectedOrder.delivery_fee) : "Gratuit"}
                    </span>
                  </div>
                  <Separator />
                  <div className="flex justify-between font-bold text-base">
                    <span className="text-foreground">Total</span>
                    <span className="text-primary">{formatPrice(selectedOrder.total)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Paye</span>
                    <span className="text-green-600 font-medium">{formatPrice(selectedOrder.amount_paid)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Reste a payer</span>
                    <span className="text-orange-600 font-medium">{formatPrice(selectedOrder.remaining_balance)}</span>
                  </div>
                </div>

                {/* Payment Form */}
                {selectedOrder.remaining_balance > 0 && selectedOrder.status !== "cancelled" && (
                  <>
                    <Separator />
                    <div>
                      <h3 className="font-semibold text-sm text-foreground mb-3">Enregistrer un paiement</h3>
                      <div className="flex items-end gap-3">
                        <div className="flex-1 space-y-2">
                          <Label className="text-xs">Montant (FCFA)</Label>
                          <Input
                            type="number"
                            value={paymentAmount}
                            onChange={(e) => setPaymentAmount(e.target.value)}
                            placeholder={String(selectedOrder.remaining_balance)}
                            min="1"
                            max={selectedOrder.remaining_balance}
                          />
                        </div>
                        <Button
                          onClick={() => recordPayment(selectedOrder.id)}
                          disabled={isUpdating}
                        >
                          {isUpdating ? (
                            <Loader2 className="h-4 w-4 animate-spin" />
                          ) : (
                            "Enregistrer"
                          )}
                        </Button>
                      </div>
                    </div>
                  </>
                )}
              </div>
              <DialogFooter>
                <Button variant="outline" className="bg-transparent" onClick={() => setDetailOpen(false)}>
                  Fermer
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
