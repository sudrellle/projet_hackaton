"use client"

import React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { useCart } from "@/lib/cart-context"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { ChefHat, ArrowLeft, Truck, Store, Loader2 } from "lucide-react"
import { formatPrice } from "@/lib/types"
import { toast } from "sonner"
import Link from "next/link"

const DELIVERY_FEE = 2000

export function CheckoutForm() {
  const { items, subtotal, clearCart } = useCart()
  const router = useRouter()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [deliveryMode, setDeliveryMode] = useState<"delivery" | "pickup">("delivery")

  const [form, setForm] = useState({
    firstName: "",
    lastName: "",
    phone: "",
    email: "",
    deliveryAddress: "",
    addressComplement: "",
    pickupPoint: "",
    deliveryDate: "",
    deliveryTime: "",
    specialInstructions: "",
  })

  const [errors, setErrors] = useState<Record<string, string>>({})

  const deliveryFee = deliveryMode === "delivery" ? DELIVERY_FEE : 0
  const total = subtotal + deliveryFee

  function validate(): boolean {
    const newErrors: Record<string, string> = {}
    if (!form.firstName.trim()) newErrors.firstName = "Le prenom est requis"
    if (!form.lastName.trim()) newErrors.lastName = "Le nom est requis"
    if (!form.phone.trim()) newErrors.phone = "Le telephone est requis"
    if (form.phone.trim() && !/^[+\d\s()-]{8,}$/.test(form.phone.trim())) {
      newErrors.phone = "Numero de telephone invalide"
    }
    if (form.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      newErrors.email = "Email invalide"
    }
    if (deliveryMode === "delivery" && !form.deliveryAddress.trim()) {
      newErrors.deliveryAddress = "L'adresse de livraison est requise"
    }
    if (deliveryMode === "pickup" && !form.pickupPoint.trim()) {
      newErrors.pickupPoint = "Le point de retrait est requis"
    }
    if (!form.deliveryDate) newErrors.deliveryDate = "La date est requise"
    if (!form.deliveryTime) newErrors.deliveryTime = "L'heure est requise"

    const selectedDate = new Date(form.deliveryDate)
    const today = new Date()
    today.setHours(0, 0, 0, 0)
    if (form.deliveryDate && selectedDate < today) {
      newErrors.deliveryDate = "La date doit etre dans le futur"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!validate()) return
    if (items.length === 0) {
      toast.error("Votre panier est vide")
      return
    }

    setIsSubmitting(true)
    const supabase = createClient()

    try {
      const { data: order, error: orderError } = await supabase
        .from("orders")
        .insert({
          order_number: "",
          client_first_name: form.firstName.trim(),
          client_last_name: form.lastName.trim(),
          client_phone: form.phone.trim(),
          client_email: form.email.trim() || null,
          delivery_mode: deliveryMode,
          delivery_address: deliveryMode === "delivery" ? form.deliveryAddress.trim() : null,
          address_complement: form.addressComplement.trim() || null,
          pickup_point: deliveryMode === "pickup" ? form.pickupPoint.trim() : null,
          delivery_date: form.deliveryDate,
          delivery_time: form.deliveryTime,
          special_instructions: form.specialInstructions.trim() || null,
          subtotal,
          delivery_fee: deliveryFee,
          total,
          status: "pending_payment",
          amount_paid: 0,
          remaining_balance: total,
        })
        .select()
        .single()

      if (orderError) throw orderError

      const orderItems = items.map((item) => ({
        order_id: order.id,
        product_id: item.product.id,
        product_name: item.product.name,
        quantity: item.quantity,
        unit_price: item.product.price,
      }))

      const { error: itemsError } = await supabase.from("order_items").insert(orderItems)
      if (itemsError) throw itemsError

      clearCart()
      router.push(`/commander/confirmation?order=${order.order_number}`)
    } catch (error) {
      console.error("Order error:", error)
      toast.error("Erreur lors de la creation de la commande. Veuillez reessayer.")
    } finally {
      setIsSubmitting(false)
    }
  }

  function updateField(field: string, value: string) {
    setForm((prev) => ({ ...prev, [field]: value }))
    if (errors[field]) {
      setErrors((prev) => {
        const next = { ...prev }
        delete next[field]
        return next
      })
    }
  }

  if (items.length === 0) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-6 px-4 bg-background">
        <ChefHat className="h-16 w-16 text-muted-foreground" />
        <h1 className="font-serif text-2xl font-bold text-foreground">Votre panier est vide</h1>
        <p className="text-muted-foreground">Ajoutez des produits avant de commander.</p>
        <Link href="/">
          <Button>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Retour a la boutique
          </Button>
        </Link>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="border-b border-border bg-card/80 backdrop-blur-sm">
        <div className="mx-auto max-w-4xl px-4 py-4 flex items-center gap-4">
          <Link href="/" className="text-muted-foreground hover:text-foreground transition-colors">
            <ArrowLeft className="h-5 w-5" />
          </Link>
          <div className="flex items-center gap-2">
            <ChefHat className="h-6 w-6 text-primary" />
            <h1 className="font-serif text-xl font-bold text-foreground">Finaliser la commande</h1>
          </div>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="mx-auto max-w-4xl px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="font-serif text-foreground">Informations personnelles</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="firstName">Prenom *</Label>
                    <Input
                      id="firstName"
                      value={form.firstName}
                      onChange={(e) => updateField("firstName", e.target.value)}
                      placeholder="Votre prenom"
                    />
                    {errors.firstName && <p className="text-sm text-destructive">{errors.firstName}</p>}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lastName">Nom *</Label>
                    <Input
                      id="lastName"
                      value={form.lastName}
                      onChange={(e) => updateField("lastName", e.target.value)}
                      placeholder="Votre nom"
                    />
                    {errors.lastName && <p className="text-sm text-destructive">{errors.lastName}</p>}
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="phone">Telephone *</Label>
                    <Input
                      id="phone"
                      value={form.phone}
                      onChange={(e) => updateField("phone", e.target.value)}
                      placeholder="+237 6XX XXX XXX"
                    />
                    {errors.phone && <p className="text-sm text-destructive">{errors.phone}</p>}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email (optionnel)</Label>
                    <Input
                      id="email"
                      type="email"
                      value={form.email}
                      onChange={(e) => updateField("email", e.target.value)}
                      placeholder="votre@email.com"
                    />
                    {errors.email && <p className="text-sm text-destructive">{errors.email}</p>}
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="font-serif text-foreground">Mode de reception</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <RadioGroup
                  value={deliveryMode}
                  onValueChange={(val) => setDeliveryMode(val as "delivery" | "pickup")}
                  className="grid grid-cols-2 gap-4"
                >
                  <Label
                    htmlFor="delivery"
                    className={`flex items-center gap-3 rounded-lg border p-4 cursor-pointer transition-colors ${
                      deliveryMode === "delivery" ? "border-primary bg-primary/5" : "border-border"
                    }`}
                  >
                    <RadioGroupItem value="delivery" id="delivery" />
                    <Truck className="h-5 w-5 text-primary" />
                    <div>
                      <p className="font-medium text-foreground text-sm">Livraison</p>
                      <p className="text-xs text-muted-foreground">{formatPrice(DELIVERY_FEE)}</p>
                    </div>
                  </Label>
                  <Label
                    htmlFor="pickup"
                    className={`flex items-center gap-3 rounded-lg border p-4 cursor-pointer transition-colors ${
                      deliveryMode === "pickup" ? "border-primary bg-primary/5" : "border-border"
                    }`}
                  >
                    <RadioGroupItem value="pickup" id="pickup" />
                    <Store className="h-5 w-5 text-primary" />
                    <div>
                      <p className="font-medium text-foreground text-sm">Retrait</p>
                      <p className="text-xs text-muted-foreground">Gratuit</p>
                    </div>
                  </Label>
                </RadioGroup>

                {deliveryMode === "delivery" && (
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="deliveryAddress">Adresse de livraison *</Label>
                      <Input
                        id="deliveryAddress"
                        value={form.deliveryAddress}
                        onChange={(e) => updateField("deliveryAddress", e.target.value)}
                        placeholder="Adresse complete"
                      />
                      {errors.deliveryAddress && <p className="text-sm text-destructive">{errors.deliveryAddress}</p>}
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="addressComplement">Complement d{"'"}adresse</Label>
                      <Input
                        id="addressComplement"
                        value={form.addressComplement}
                        onChange={(e) => updateField("addressComplement", e.target.value)}
                        placeholder="Etage, batiment..."
                      />
                    </div>
                  </div>
                )}

                {deliveryMode === "pickup" && (
                  <div className="space-y-2">
                    <Label htmlFor="pickupPoint">Point de retrait *</Label>
                    <Input
                      id="pickupPoint"
                      value={form.pickupPoint}
                      onChange={(e) => updateField("pickupPoint", e.target.value)}
                      placeholder="Point de retrait souhaite"
                    />
                    {errors.pickupPoint && <p className="text-sm text-destructive">{errors.pickupPoint}</p>}
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="deliveryDate">Date souhaitee *</Label>
                    <Input
                      id="deliveryDate"
                      type="date"
                      value={form.deliveryDate}
                      onChange={(e) => updateField("deliveryDate", e.target.value)}
                    />
                    {errors.deliveryDate && <p className="text-sm text-destructive">{errors.deliveryDate}</p>}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="deliveryTime">Heure souhaitee *</Label>
                    <Input
                      id="deliveryTime"
                      type="time"
                      value={form.deliveryTime}
                      onChange={(e) => updateField("deliveryTime", e.target.value)}
                    />
                    {errors.deliveryTime && <p className="text-sm text-destructive">{errors.deliveryTime}</p>}
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="font-serif text-foreground">Instructions speciales</CardTitle>
              </CardHeader>
              <CardContent>
                <Textarea
                  value={form.specialInstructions}
                  onChange={(e) => updateField("specialInstructions", e.target.value)}
                  placeholder="Allergie, message sur le gateau, autres instructions..."
                  rows={3}
                />
              </CardContent>
            </Card>
          </div>

          <div className="lg:col-span-1">
            <Card className="sticky top-24">
              <CardHeader>
                <CardTitle className="font-serif text-foreground">Recapitulatif</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {items.map((item) => (
                  <div key={item.product.id} className="flex justify-between text-sm gap-2">
                    <span className="text-foreground truncate">
                      {item.product.name} x{item.quantity}
                    </span>
                    <span className="text-muted-foreground flex-shrink-0">
                      {formatPrice(item.product.price * item.quantity)}
                    </span>
                  </div>
                ))}
                <Separator />
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Sous-total</span>
                  <span className="text-foreground">{formatPrice(subtotal)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Livraison</span>
                  <span className="text-foreground">
                    {deliveryFee > 0 ? formatPrice(deliveryFee) : "Gratuit"}
                  </span>
                </div>
                <Separator />
                <div className="flex justify-between font-bold text-lg">
                  <span className="text-foreground">Total</span>
                  <span className="text-primary">{formatPrice(total)}</span>
                </div>
                <Button
                  type="submit"
                  form="checkout-form"
                  className="w-full rounded-full mt-4"
                  size="lg"
                  disabled={isSubmitting}
                  onClick={handleSubmit}
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Envoi en cours...
                    </>
                  ) : (
                    "Confirmer la commande"
                  )}
                </Button>
                <p className="text-xs text-center text-muted-foreground">
                  Le paiement se fait a la reception ou au retrait.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </form>
    </div>
  )
}
