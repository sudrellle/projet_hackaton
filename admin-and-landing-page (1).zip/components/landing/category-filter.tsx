"use client"

import { Button } from "@/components/ui/button"
import type { Category } from "@/lib/types"

interface CategoryFilterProps {
  categories: Category[]
  selectedCategory: string | null
  onSelect: (id: string | null) => void
}

export function CategoryFilter({ categories, selectedCategory, onSelect }: CategoryFilterProps) {
  return (
    <div className="flex flex-wrap items-center justify-center gap-3 mb-10">
      <Button
        variant={selectedCategory === null ? "default" : "outline"}
        size="sm"
        className={`rounded-full ${selectedCategory !== null ? 'bg-transparent' : ''}`}
        onClick={() => onSelect(null)}
      >
        Tous
      </Button>
      {categories.map((cat) => (
        <Button
          key={cat.id}
          variant={selectedCategory === cat.id ? "default" : "outline"}
          size="sm"
          className={`rounded-full ${selectedCategory !== cat.id ? 'bg-transparent' : ''}`}
          onClick={() => onSelect(cat.id)}
        >
          {cat.name}
        </Button>
      ))}
    </div>
  )
}
