import React from "react"
import { createClient } from "@/lib/supabase/server"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Package, ShoppingCart, DollarSign, TrendingUp } from "lucide-react"
import { formatPrice } from "@/lib/types"

export default async function AdminDashboardPage() {
  const supabase = await createClient()

  const { count: productsCount } = await supabase
    .from("products")
    .select("*", { count: "exact", head: true })
    .eq("deleted", false)

  const { count: ordersCount } = await supabase
    .from("orders")
    .select("*", { count: "exact", head: true })

  const { data: orders } = await supabase
    .from("orders")
    .select("total, status")

  const totalRevenue = orders?.reduce((sum, o) => sum + (o.total || 0), 0) || 0
  const pendingOrders = orders?.filter((o) => o.status === "pending_payment").length || 0

  const { data: recentOrders } = await supabase
    .from("orders")
    .select("*")
    .order("created_at", { ascending: false })
    .limit(5)

  return (
    <div>
      <div className="mb-8">
        <h1 className="font-serif text-3xl font-bold text-foreground">Tableau de bord</h1>
        <p className="text-muted-foreground mt-1">Vue d{"'"}ensemble de votre patisserie</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard
          title="Produits"
          value={String(productsCount || 0)}
          icon={<Package className="h-5 w-5" />}
        />
        <StatCard
          title="Commandes"
          value={String(ordersCount || 0)}
          icon={<ShoppingCart className="h-5 w-5" />}
        />
        <StatCard
          title="Chiffre d'affaires"
          value={formatPrice(totalRevenue)}
          icon={<DollarSign className="h-5 w-5" />}
        />
        <StatCard
          title="En attente"
          value={String(pendingOrders)}
          icon={<TrendingUp className="h-5 w-5" />}
        />
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="font-serif text-foreground">Commandes recentes</CardTitle>
        </CardHeader>
        <CardContent>
          {!recentOrders || recentOrders.length === 0 ? (
            <p className="text-muted-foreground text-sm py-4 text-center">
              Aucune commande pour le moment.
            </p>
          ) : (
            <div className="space-y-3">
              {recentOrders.map((order) => (
                <div
                  key={order.id}
                  className="flex items-center justify-between p-3 rounded-lg bg-muted/50"
                >
                  <div>
                    <p className="font-mono text-sm font-medium text-foreground">{order.order_number}</p>
                    <p className="text-xs text-muted-foreground">
                      {order.client_first_name} {order.client_last_name}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-sm text-primary">{formatPrice(order.total)}</p>
                    <p className="text-xs text-muted-foreground capitalize">
                      {order.status.replace("_", " ")}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

function StatCard({ title, value, icon }: { title: string; value: string; icon: React.ReactNode }) {
  return (
    <Card>
      <CardContent className="pt-6">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm text-muted-foreground">{title}</span>
          <span className="text-primary">{icon}</span>
        </div>
        <p className="text-2xl font-bold text-foreground">{value}</p>
      </CardContent>
    </Card>
  )
}
