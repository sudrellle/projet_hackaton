import { CheckCircle, ArrowLeft, ChefHat } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"

export default async function ConfirmationPage({ searchParams }: { searchParams: Promise<{ order?: string }> }) {
  const params = await searchParams
  const orderNumber = params.order || "N/A"

  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-4">
      <Card className="max-w-md w-full">
        <CardContent className="pt-8 pb-8 text-center space-y-6">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-100 mx-auto">
            <CheckCircle className="h-8 w-8 text-green-600" />
          </div>
          <div>
            <h1 className="font-serif text-2xl font-bold text-foreground mb-2">
              Commande confirmee !
            </h1>
            <p className="text-muted-foreground leading-relaxed">
              Votre commande a ete enregistree avec succes. Nous vous contacterons
              pour confirmer les details.
            </p>
          </div>
          <div className="bg-muted rounded-lg p-4">
            <p className="text-sm text-muted-foreground mb-1">Numero de commande</p>
            <p className="font-mono font-bold text-lg text-foreground">{orderNumber}</p>
          </div>
          <div className="bg-accent/50 rounded-lg p-4 flex items-start gap-3">
            <ChefHat className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
            <p className="text-sm text-foreground text-left leading-relaxed">
              Le paiement se fait a la reception de votre commande ou lors du retrait 
              en boutique. Conservez votre numero de commande.
            </p>
          </div>
          <Link href="/">
            <Button className="rounded-full" size="lg">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Retour a la boutique
            </Button>
          </Link>
        </CardContent>
      </Card>
    </div>
  )
}
