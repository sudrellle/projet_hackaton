export interface Category {
  id: string
  name: string
  description: string | null
  created_at: string
  updated_at: string
}

export interface Product {
  id: string
  name: string
  description: string | null
  price: number
  image_url: string | null
  category_id: string
  available: boolean
  quantity: number
  deleted: boolean
  created_by: string | null
  created_at: string
  updated_at: string
  categories?: Category
}

export interface Order {
  id: string
  order_number: string
  client_first_name: string
  client_last_name: string
  client_phone: string
  client_email: string | null
  delivery_mode: 'delivery' | 'pickup'
  delivery_address: string | null
  address_complement: string | null
  pickup_point: string | null
  delivery_date: string
  delivery_time: string
  special_instructions: string | null
  subtotal: number
  delivery_fee: number
  total: number
  status: OrderStatus
  amount_paid: number
  remaining_balance: number
  created_at: string
  updated_at: string
  order_items?: OrderItem[]
}

export type OrderStatus =
  | 'pending_payment'
  | 'paid'
  | 'partially_paid'
  | 'confirmed'
  | 'preparing'
  | 'ready'
  | 'delivered'
  | 'cancelled'

export interface OrderItem {
  id: string
  order_id: string
  product_id: string
  product_name: string
  quantity: number
  unit_price: number
  special_instructions: string | null
  created_at: string
}

export interface CartItem {
  product: Product
  quantity: number
  special_instructions?: string
}

export const ORDER_STATUS_LABELS: Record<OrderStatus, string> = {
  pending_payment: 'En attente de paiement',
  paid: 'Paye',
  partially_paid: 'Partiellement paye',
  confirmed: 'Confirme',
  preparing: 'En preparation',
  ready: 'Pret',
  delivered: 'Livre',
  cancelled: 'Annule',
}

export const ORDER_STATUS_COLORS: Record<OrderStatus, string> = {
  pending_payment: 'bg-amber-100 text-amber-800',
  paid: 'bg-green-100 text-green-800',
  partially_paid: 'bg-orange-100 text-orange-800',
  confirmed: 'bg-blue-100 text-blue-800',
  preparing: 'bg-indigo-100 text-indigo-800',
  ready: 'bg-emerald-100 text-emerald-800',
  delivered: 'bg-teal-100 text-teal-800',
  cancelled: 'bg-red-100 text-red-800',
}

export function formatPrice(priceInCents: number): string {
  return new Intl.NumberFormat('fr-FR').format(priceInCents) + ' FCFA'
}
