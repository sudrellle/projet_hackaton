"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Plus, ImageIcon } from "lucide-react"
import { useCart } from "@/lib/cart-context"
import { formatPrice, type Product } from "@/lib/types"
import { toast } from "sonner"

interface ProductGridProps {
  products: Product[]
}

export function ProductGrid({ products }: ProductGridProps) {
  const { addItem } = useCart()

  if (products.length === 0) {
    return (
      <div className="text-center py-16">
        <ImageIcon className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
        <p className="text-muted-foreground text-lg">Aucun produit disponible pour le moment.</p>
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {products.map((product) => (
        <Card key={product.id} className="group overflow-hidden border-border hover:shadow-lg transition-shadow duration-300">
          <div className="aspect-square relative overflow-hidden bg-muted">
            {product.image_url ? (
              <img
                src={product.image_url || "/placeholder.svg"}
                alt={product.name}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                crossOrigin="anonymous"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center">
                <ChefHatPlaceholder />
              </div>
            )}
            {product.categories && (
              <Badge className="absolute top-3 left-3 bg-card/90 text-foreground backdrop-blur-sm border-0 text-xs">
                {product.categories.name}
              </Badge>
            )}
            {product.quantity <= 5 && product.quantity > 0 && (
              <Badge variant="destructive" className="absolute top-3 right-3 text-xs">
                Plus que {product.quantity}
              </Badge>
            )}
          </div>
          <CardContent className="p-4">
            <h3 className="font-serif font-semibold text-lg text-foreground mb-1 truncate">
              {product.name}
            </h3>
            {product.description && (
              <p className="text-sm text-muted-foreground mb-3 line-clamp-2 leading-relaxed">
                {product.description}
              </p>
            )}
            <div className="flex items-center justify-between">
              <span className="font-bold text-lg text-primary">
                {formatPrice(product.price)}
              </span>
              <Button
                size="sm"
                className="rounded-full"
                disabled={product.quantity <= 0}
                onClick={() => {
                  addItem(product, 1)
                  toast.success(`${product.name} ajoute au panier`)
                }}
              >
                <Plus className="h-4 w-4 mr-1" />
                Ajouter
              </Button>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

function ChefHatPlaceholder() {
  return (
    <div className="flex flex-col items-center justify-center gap-2 text-muted-foreground">
      <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
        <path d="M17 21a1 1 0 0 0 1-1v-5.35c0-.457.316-.844.727-1.041a4 4 0 0 0-2.134-7.589 5 5 0 0 0-9.186 0 4 4 0 0 0-2.134 7.588c.411.198.727.585.727 1.041V20a1 1 0 0 0 1 1Z" />
        <path d="M6 17h12" />
      </svg>
      <span className="text-xs">Pas d{"'"}image</span>
    </div>
  )
}
